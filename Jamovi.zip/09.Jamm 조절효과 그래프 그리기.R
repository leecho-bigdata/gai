

# install.packages("tidyverse")
library(tidyverse)

# 독립변수 X의 값 설정 (중심화되어 있다고 가정)
X_vals <- seq(-2, 2, by = 0.1)

# 세 가지 기울기를 사용하여 Y값 계산
data_lines <- tibble(
  X = rep(X_vals, 3),
  Moderator = factor(rep(c("Low(-1SD)", "Mean", "High(+1SD)"), 
                         each = length(X_vals)),
                     levels = c("Low(-1SD)", "Mean", "High(+1SD)")),
  Y = c(0.449 * X_vals,  # 간접효과 = slope
        0.512 * X_vals,
        0.575 * X_vals)
)

# 회귀직선 그래프 그리기
data_lines |> 
  ggplot(aes(x = X, y = Y, 
             color = Moderator)) +
  geom_line(size = 0.7) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
  labs(title = "조절효과",
       x = "X",
       y = "Y",
       color = "Mo1") +
  theme_minimal(base_size = 14)

